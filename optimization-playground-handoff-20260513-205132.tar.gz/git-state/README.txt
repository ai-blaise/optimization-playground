Git command capture skipped by default to keep handoff packing fast and avoid
local submodule/filesystem stalls. Run with OP_HANDOFF_CAPTURE_GIT=1 to capture
remotes, branch, HEAD, recent log, status, and worktree metadata.
